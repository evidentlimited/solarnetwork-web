module.exports = [
  ['temperature','heat','hot','cold'],
  ['humidity','humid'],
  ['co2','carbon dioxide'],
  ['energy']
]
