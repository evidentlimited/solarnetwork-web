module.exports = [
  ['lounge','living room'],
  ['bathroom','shower'],
  ['outside','outdoors']
]
