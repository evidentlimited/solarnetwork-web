module.exports = [
  ['second'],
  ['minute'],
  ['hour'],
  ['day'],
  ['week'],
  ['month'],
  ['year']
]
